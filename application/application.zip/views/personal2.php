 
<?php include("header.php"); ?>
<section class="main_content ss_sign_up_content bg-gray animatedParent">
		<div class="container-fluid container-fluid_padding">
			<div class="row"> 
				 <div class="sign_up_header">
				 	<div class="col-sm-4"></div>
				 	<div class="col-sm-4 text-center">
				 		<a href="#"><img src="assets/images/logo_signup.png"></a>
				 	</div>
				 	<div class="col-sm-4">
				 		<div class="top_signup">
				 			<ul>
				 				<li><a href="#">Back</a></li>
				 				<li><a href="#"><img src="assets/images/icon_video.png"/> Video Help </a><span>1</span></li>
				 			</ul>
				 		</div>
				 	</div>
				 </div>

				 
				 


			</div> 
			<div class="container">
				<div class="row">
				<div class="sign_my_acount">
				<div class="col-md-4 col-md-offset-4">
					<p class="accordion_new">
						<a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1"><i class="fa fa-sort-down"></i> My Account</a>
					  </p>
					<div class="">
					  <div class="col">
						<div class="collapse multi-collapse accordion_body in" id="multiCollapseExample1">
						  <div class="card card-body">
							<ul>
								<li><a href="my_details.php">Setting</a></li>
								<li><a href="#">Logo/Photo</a></li>
								<li><a href="#">Cancel/Subscription</a></li>
								<li><a href="#">Enrollment List</a></li>
							</ul>	
							</div>
						</div>
					  </div> 
					</div>
				</div>
				</div>
			 </div>
			 </div>
		</div>
</section>
<?php include("footer.php"); ?>
 