<div class="row">
    <div class="">

        <ul class="personal_ul">
            <li class="presonal"><a href="<?php echo base_url();?>tutor_setting">Personal</a></li>
            <li class="presonal2"><a href="student_progress">View Progress</a></li>
            <li class="presonal2"><a href="course/country">Course</a></li>
            <!-- <li class="presonal2"><a href="course/data_input">Data Input</a></li> -->
        </ul>

        <div>
            <img style="margin:20px auto;" src="assets/images/personal_n1.png" class="img-responsive">
        </div>

    </div>
</div>
