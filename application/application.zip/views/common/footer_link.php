	<!--===================== Footer ========================-->
<footer class="new_footer">
	<div class="footer_extra_bg"><img src="<?php echo base_url();?>assets/images/18.png"></div>
	<div class="container-fluid">
		<div class="ss_container_rs">
		<div class="copyright row">
			<div class="footer_link col-sm-6">
				<ul>
					<li><a href="faq/view/other/terms_and_conditions">Terms & Conditions</a></li>
					<li><a href="faq/view/other/privacy_policy">Privacy Policy</a></li>
					<li><a href="faq/view/other/disclaimer">Disclaimer</a></li>
				</ul>
			</div>
			<div class="col-sm-6 text-right">

				<p> Copyright Q-Study &copy; 2014- <?php echo date("Y"); ?> </p>
			</div>
			</div>
		</div><!--copyright-->
	</div>
</footer>