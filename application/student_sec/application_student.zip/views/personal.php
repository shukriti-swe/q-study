 
<?php include("header.php"); ?>
<section class="main_content ss_sign_up_content bg-gray animatedParent">
		<div class="container-fluid container-fluid_padding">
			<div class="row"> 
				 <div class="sign_up_header">
				 	<div class="col-sm-4"></div>
				 	<div class="col-sm-4 text-center">
				 		<a href="#"><img src="assets/images/logo_signup.png"></a>
				 	</div>
				 	<div class="col-sm-4">
				 		<div class="top_signup">
				 			<ul>
				 				<li><a href="#">Back</a></li>
				 				<li><a href="#"><img src="assets/images/icon_video.png"/> Video Help </a><span>1</span></li>
				 			</ul>
				 		</div>
				 	</div>
				 </div>

				 
				 


			</div> 
			<div class="container">
				<div class="row">
				<div class="">
					<ul class="personal_ul">
						<li class="presonal"><a href="personal2.php">Personal</a></li>
						<li class="presonal2"><a href="#">View Progress</a></li>
						<li class="presonal2"><a href="#">Course</a></li>
					</ul>
					<div ><img style="margin:20px auto;" src="assets/images/personal_n1.png" class="img-responsive"></div>
				</div>
			 </div>
			 </div>
		</div>
</section>
<?php include("footer.php"); ?>
 