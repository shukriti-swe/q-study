<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IEedge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title></title>
 <style></style>
 </head>
 <body style="height: 100%;margin: 0;padding: 0;width: 100%;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;background:#c3c3c3;">
 <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable">
 <tr>
 <td>
 <table style="width: 100%" border="0" cellpadding="20" cellspacing="0" width="600" id="emailContainer">
 <tr>
 <td align="center" valign="center"> <img src="https://q-study.com/assets/images/r_c_l.png" alt="student"></td>
 </tr>
 </table>
 </td>
 <td align="center" style="background: #fff; width:600px;" valign="top">
 <table style="width: 100%;" border="0" cellpadding="20" cellspacing="0" width="600" id="emailContainer">
 <tr>
 <td align="center" valign="top">
 <table border="0" cellpadding="20" cellspacing="0" width="100%" id="emailHeader">
 <tr>
 <td align="center" valign="top"><img src="https://q-study.com/assets/images/logo_signup.png" alt="logo" style="width: 37%;"></td>
 </tr>
 </table>
 </td>
 </tr>
 <tr>
 <td align="center" valign="top">
 <table border="0" cellpadding="20" cellspacing="0" width="100%" id="emailBody">
 <tr>
 <td align="center" valign="top">
 <h1 style="display: block;margin: 0;padding:0;color: #202020;font-family: Helvetica;font-size: 19px;font-style: normal;font-weight: bold;line-height: 125%;letter-spacing: normal;text-align: left ;">Hello, {{parentname}}</h1>
 <p style="line-height: 125%;margin: 10px 0;padding: 0;mso-line-height-rule: exactly;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color:#202020;font-family: Helvetica;font-size: 16px;text-align: left;">Thank you for subscribing Q-study
 <br>
 Your Choosen Product:<br>
 {{coruse_list}}
 <br><br>
<!--<span style="font-size: 14px;">OC Tests (AUS) $10</span><br>-->
<span>Total: ${{total_amount}}</span><br><br>
 Please make payment of 
 <span style="color:blue;" >{{money}}</span> to Q-study
 </p> 

<div style="text-align: left;">
    {{bank_details}}
</div>
 <!--<table style="width:100%">-->
 <!--<tr>-->
 <!--<th></th>-->
 <!--<th></th>-->
 <!--</tr>-->
 <!--<tr>-->
 <!--<td> <b>Account Name:</b> </td>-->
 <!--<td>{{acount_name}}</td>-->
 <!--</tr>-->
 <!--<tr>-->
 <!--<td> <b>BSB</b> </td>-->
 <!--<td>{{bsb}}</td>-->
 <!--</tr>-->
 <!--<tr>-->
 <!--<td> <b>Account Number</b> </td>-->
 <!--<td>{{account_number}}</td>-->
 <!--</tr>-->
 <!--<tr>-->
 <!--<td> <b>Bank</b> </td>-->
 <!--<td>{{bank}}</td>-->
 <!--</tr>-->
 <!--</table>-->

<p style="text-align: left;color: #44448a;">After payment has been made, please email us so we can active your acount without delay. Please write your name,email address and your Ref.Link <span></span> as the reference.  </p>
<p style="text-align: left;color: #44448a;">Moreover, the message and direct deposit information are given in the inboxof the front page of the student.</p>

 </td>
 </tr>
 <tr>
 <td align="center" valign="top">
 <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailFooter">
 <tr>
 <td align="center" valign="top">
 <p style="line-height: 125%;margin: 0px 0;padding: 0;mso-line-height-rule: exactly;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;color: #202020;font-family: Helvetica;font-size: 16px;text-align: left; padding-left: 0px;">Thanks, &nbsp; <a href="http://qstudy.com" style="color: black;mso-line-height-rule: exactly;-ms-text-size-adjust: 100%;-webkit-text-size-adjust: 100%;font-weight: normal;text-decoration: underline;"> <br> <br> <b>Q-Study</b> </a></p>
 <br>
 <br>
 <br>
 </td>
 </tr>
 </table>
 </td>
 </tr>
 </table>
 </td>
 </tr>
 </table>
 </td>
 <td>
 <table style="width: 100%" border="0" cellpadding="20" cellspacing="0" width="600" id="emailContainer">
 <tr>
 <td align="center" valign="center" style="text-align: center;"> <img src="https://q-study.com/assets/images/r_c_r.png" alt="logo"></td>
 </tr>
 </table>
 </td>
 </tr>
 </table>
 </body>
</html>