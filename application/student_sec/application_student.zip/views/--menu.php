<header class="new_header">
  <div class="container-fluid">
    <div class="ss_container_rs">
    <div class="row">
      <div class="col-md-2 mr-auto">
        <a href="<?php echo base_url();?>" class="logo"><img src="<?php echo base_url();?>assets/images/logo.png" alt="logo"></a>
      </div>
      <div class="col-md-3 run_img_header">
        
          <img class="img-responsive" src="<?php echo base_url();?>assets/images/h_top_runpeople.png" alt="run">
 
      </div>
      <div class="col-md-2 m-auto">
        <div class="top_menu">
          <ul>
            <li>
              <a href="javascript:;" class="top_menu_link"><img class="img-responsive" src="<?php echo base_url();?>assets/images/h_top_menu_icon.png" alt="run"></a>
               <ul class="ss_new_menu">
                                       
                   <li><a href="faq/view/25">  How it Works</a></li>

                   <li><a href="<?php echo base_url();?>trial">  Try free</a></li>

                  <li><a href="faq/view/other/pricing">  Pricing</a></li>
                  
                 
                  
                  <li><a href="faq/view/other/about_us">  About us</a></li>
                  
                  <li><a href="contact_us">  Contact</a></li>
                  
                   
                  
                </ul>
            </li>
            <li>
              <a href="faq/view/33"><img class="img-responsive" src="<?php echo base_url();?>assets/images/h_top_faq_icon.png" alt="run"></a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 rs_r run_img_header">
  
          <img class="img-responsive" src="<?php echo base_url();?>assets/images/h_top_edu_icon.png" alt="run">
       
      </div>
      <div class="col-md-2 text-right login_nav">
        <div class="top_menu_login">
          <li>
            <a href="<?php echo base_url();?>trial">
              <img src="<?php echo base_url();?>assets/images/trial.png"> Sign-Up
            </a>
          </li>
          <li>
            <a href="<?php echo base_url();?>signup">
              <img src="<?php echo base_url();?>assets/images/h_top_signin_icon.png"> Sign-Up
            </a>
          </li>
                    
          <li>
            <a href="javascript:;" data-toggle="modal" data-target="#login_form">
              <img src="<?php echo base_url();?>assets/images/h_top_login_icon.png"> Login
            </a>
          </li>
        </div>
      </div>
    </div>
  </div>
  </div>

</header>