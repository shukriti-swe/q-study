<div class="row">
    <div class="">

        <ul class="personal_ul">
            <li class="presonal2"><a href="question-list">Question</a></li>
            <li class="presonal2"><a href="all-module">Module/Event</a></li>
        </ul>

        <div>
            <img style="margin:20px auto;" src="assets/images/personal_n1.png" class="img-responsive">
        </div>

    </div>
</div>
