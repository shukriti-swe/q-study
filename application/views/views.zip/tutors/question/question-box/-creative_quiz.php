<style>
    .input-group-prepend {
        position: absolute;
        right: 20px;
        top: 2px;
        bottom: 10px;
        z-index: 9;
    }
</style>
<input type="hidden" name="questionType" value="9">
<div class="col-sm-4">
    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                    <a role="button" aria-expanded="true" aria-controls="collapseOne">
                         Question
                    </a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                <textarea class="mytextarea" name="questionName"></textarea>
            </div>
        </div>
    </div>
	<div id="clue" class="" style="display: none">
        <div class="1st_atmp" style="margin-bottom: 20px;padding: 10px 0px;">
            <div class="form-group">
                <label style="margin-bottom: 10px;">1st attempt</label>
                <input autocomplete="off" type="text" class="form-control" id="first_atmp_text" name="first_atmp_text">
                <span class="first_atmp_text_msg"></span>
            </div>
            <div class="form-group row">
                <label style="padding-right: 0px;margin-top: 7px;" class="col-sm-4 col-form-label">How many box</label>
                <div class="col-sm-3" style="padding-left: 0px;">
                    <input autocomplete="off" type="number" class="form-control" id="1st_box_item">
                    <span class="1st_box_item_msg"></span>
                </div>
            </div>
            <div class="atmp-input" id="1st_atmp_input">

            </div>
        </div>
        <div class="2st_atmp" style="margin-bottom: 20px;padding: 10px 0px;clear: both;">
            <div class="form-group">
                <label style="margin-bottom: 10px;">2nd attempt</label>
                <input autocomplete="off" type="text" class="form-control" id="second_atmp_text" name="second_atmp_text">
                <span class="second_atmp_text_msg"></span>
            </div>
            <div class="form-group row">
                <label style="padding-right: 0px;margin-top: 7px;" class="col-sm-4 col-form-label">How many box</label>
                <div class="col-sm-3" style="padding-left: 0px;">
                    <input autocomplete="off" type="number" class="form-control" id="2nd_box_item">
                    <span class="2nd_box_item_msg"></span>
                </div>
            </div>
            <div class="atmp-input" id="2nd_atmp_input">

            </div>
        </div>
        <div class="3rd_atmp" style="margin-bottom: 20px;padding: 10px 0px;clear: both;">
            <div class="form-group">
                <label style="margin-bottom: 10px;">3rd attempt</label>
                <input autocomplete="off" type="text" class="form-control" id="three_atmp_text" name="three_atmp_text">
                <span class="three_atmp_text_msg"></span>
            </div>
            <div class="form-group row">
                <label style="padding-right: 0px;margin-top: 7px;" class="col-sm-4 col-form-label">How many box</label>
                <div class="col-sm-3" style="padding-left: 0px;">
                    <input autocomplete="off" type="number" class="form-control" id="3rd_box_item">
                    <span class="3rd_box_item_msg"></span>
                </div>
            </div>
            <div class="atmp-input" id="3rd_atmp_input">

            </div>
        </div>
    </div>
</div>

<div class="col-sm-8">

    <div class="row">
        <div class="col-md-12">
            <div class="col-md-5">
                <div class="form-group ss_h_mi">
                    <label for="exampleInputiamges1">How many sentences</label>

                    <div class="select" style="max-width: 100px;">
                        <input class="form-control" type="number" value="1" min="1" id="box_qty">
                    </div>
                </div>
            </div>
			<div class="col-md-2">
                <div class="form-group ss_h_mi">
                    <button class="btn btn-info" id="clue_answer" type="button">Clue Answer</button>
                </div>
            </div>
            <div class="col-md-5">
                <!-- <div class="form-group ss_h_mi pull-left">
                    <button class="btn btn-info" id="create_paragraph" type="button">Create Paragraph</button>
                </div> -->
                <div class="order">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-body" id="questionBody">

            <div class="row sentence" id="sreial_1" style="margin-bottom:10px" serial="1">
                <div class="col-md-8" style="display: inline-block;position: relative;">
                    <input type="text" class="form-control" value="" name="sentence[]">
                    <div class="input-group-prepend">
                        <button type="button" class="btn btn-primary btn-sm" id="paragraph_order1" onclick="paragraph_order('1')">P</button>
                        <input type="hidden" name="paragraph_order[]" id="para_order_1" >
                    </div>
                </div>
<!--                <div class="col-md-8">
                    <input type="text" class="form-control" value="" name="sentence[]">
                </div>-->
                <div class="col-md-1">
                    <input checkboxId="1" type="checkbox" id="quesChecked">
                </div>
                <div class="col-md-2">
                    <input  type="text" class="form-control questionOrder" value="" min="1" id="qOrdr1">
                </div>
                <div class="col-md-1">
                    <a data-toggle="modal" data-target="#exampleModal" class="text-center addDescIcon" data-id="1">
                        <img src="assets/images/icon_details.png">
                    </a>
                    <input type="hidden" name="description[]" id="hiddenDesc_1" value="">
                </div>
            </div>
        </div>
    </div>

</div>

<!-- <div class="col-sm-2">
  <div class="text-right">
    <div class="form-group ss_h_mi">
      <label for="exampleInputiamges1">Description</label>
    </div>
  </div>
</div> -->

<!-- add description modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="exampleModalLabel">Save Description</h4>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="message-text" class="control-label mb-2">Description:</label>
                    <textarea class="form-control" id="description"></textarea>
                </div>
            </div>
            <div class="modal-footer">

                <button type="button" class="btn btn-primary save_description_btn" id="descSaveBtn">Save</button>
            </div>
        </div>
    </div>
</div>

<input type="hidden"  id="modalOpenFor" value="">
<input type="hidden" name="ansSequence" id="ansSequence" value="">
<input type="hidden" name="para_sequence" id="para_sequence" value="">
<input type="hidden" name="sentence_sequence" id="sentence_sequence" value="">

<script>
    var prev_box_data = 1;
    $('#box_qty').on('input', function(){
        ordr = 1;
        var boxes = $('#box_qty').val();
        console.log(prev_box_data);
        var html = '';
        if(boxes != ''){
            if(parseInt(boxes - prev_box_data) > 0) {
                var j = parseInt(prev_box_data) + 1;
                console.log(j);
                for (var i = 1; i <= parseInt(boxes - prev_box_data) ; i++) {
                    html += `
                    <div class="row sentence" id="sreial_`+j+`" style="margin-bottom:10px" serial="`+j+`"> 
                        <div class="col-md-8" style="display: inline-block;position: relative;">
                            <input type="text" class="form-control" value="" name="sentence[]">
                            <div class="input-group-prepend">
                                <button type="button" class="btn btn-primary btn-sm" id="paragraph_order`+j+`" onclick="paragraph_order(`+j+`)">P</button>
                                <input type="hidden" name="paragraph_order[]" id="para_order_`+j+`" >
                            </div>
                        </div>
                        <div class="col-md-1">
                            <input checkboxId="`+j+`" type="checkbox" id="quesChecked">
                        </div>
                        <div class="col-md-2" >
                            <input  type="text" class="form-control questionOrder" value="" min="1" id="qOrdr`+j+`">
                        </div>
                        <div class="col-md-1">
                        <a data-toggle="modal" data-target="#exampleModal" data-id="`+j+`" class="text-center addDescIcon">
                            <img src="assets/images/icon_details.png">
                        </a>
                        <input type="hidden" name="description[]" id="hiddenDesc_`+j+`" value="">
                        </div>
                    </div>`;
            
                    j++;
                }
                
                $('#questionBody').append(html);
            } else {
                var list = $(".sentence").map(function(){return $(this).attr("serial");}).get();
                list.reverse();
                console.log(list);
                var j = 0;
                for (var i = boxes; i < list.length; i++) {
                    $("#sreial_"+list[j]).remove();
                    j++;
                }
            }
            
            $("#sentence_sequence").val(boxes);
            prev_box_data = $("#sentence_sequence").val();

            
        }

    })

    $(document).ready(function () {

        //question checkbox check functionality
        //generate order automatically
        var ordr = 1;
        var rightAnsSequence = [];
        $(document).on('change', '#quesChecked', function () {
          //var x = $(this).closest('div#sentence').children('#qOrdr');
            var id= $(this).attr("checkboxId");
            var qOrdr =  $("#qOrdr"+id);

            if (this.checked) {
                qOrdr.prop('disabled', true);
                qOrdr.val(ordr++);
                rightAnsSequence.push(id); //push the right ans index
            } else {
                qOrdr.prop('disabled', false);
                ordr--;
                qOrdr.val('');

            //remove the index from right ans item
                rightAnsSequence = jQuery.grep(rightAnsSequence, function(value) {
                    return value != id;
                });
            }
            
            var seq = (JSON.stringify(rightAnsSequence));
            $('#ansSequence').val(seq);
        });

    });

  //save description on hidden field
    $('#descSaveBtn').on('click', function(){
        $('#exampleModal').modal('toggle');
        var descValue = $('#description').val();
        console.log(descValue);
        var descForId = $('#modalOpenFor').val();
        $('#hiddenDesc_'+descForId).val(descValue);
    });

  //clear description modal text
    $(document).on('click','.addDescIcon', function(){
        var desc_sequence = $(this).data("id");
        console.log(desc_sequence);
        $('.save_description_btn').attr('id','descSaveBtn'+desc_sequence); 
        $('#description').val($('#hiddenDesc_'+desc_sequence).val());
        var id = $(this).closest('div.sentence').attr('serial');
        $('#modalOpenFor').val(id);
    });
    
    var btn_click = 0;
    $("#create_paragraph").click( function (){
        btn_click++;
        var add_btn = '<button class="btn btn-default" style="margin: 0px 5px 5px 5px;" type="button" onclick="set_senetence_paragraph('+btn_click+')">'+btn_click+'</button>';
        var inputs = $(".questionOrder");
        $("#para_sequence").val(btn_click);
        console.log(inputs);
        
        $('.order').append(add_btn);
    })
    
    function paragraph_order(sentence_list_order){
        $("#para_sequence").val();
        $("#para_order_"+sentence_list_order).val($("#para_sequence").val());
        $("#paragraph_order"+sentence_list_order).html('P'+$("#para_sequence").val());
		
		var i = 1;
		$(".questionOrder").each(function() {
			if($(this).val() >= i){
                $("#para_order_"+i).val($("#para_sequence").val());
            }
            i++;
		});
    }
    
    function set_senetence_paragraph(btn_click){
        $("#para_sequence").val(btn_click);
    }
</script>

<!--aftab script-->

<script>
    $("#clue_answer").click(function () {
        var classValue = $('#clue').hasClass('active');

        if (classValue == true)
        {
            $("#accordion").show();
            $("#clue").hide();
            $("#clue").removeClass("active");
        }else
        {
            $("#accordion").hide();
            $("#clue").show();
            $("#clue").addClass("active");
        }
        console.log(classValue);
    });

    $('#1st_box_item').on('input', function(){
        var prev_box_data = 0;
        ordr = 1;
        var boxes = $('#1st_box_item').val();
        // console.log(prev_box_data);

        var html = '';
        if(boxes != ''){
            if(parseInt(boxes - prev_box_data) >= 0) {
                var j = parseInt(prev_box_data) + 1;
                console.log(j);
                console.log(boxes);
                // return false;
                for (var i = 1; i <= parseInt(boxes - prev_box_data) ; i++) {
                    html += `
                       <input required id="1st_box_serial_`+j+`" 1st_box_serial="`+j+`" style="width: 45px;height: 30px;border: 1px solid #d4d3d3;margin: 4px;float: left;" autocomplete="off" type="number" class="1st_input_value" name="1st_input_value[]">
                    `;
                    j++;
                }
                $('#1st_atmp_input').html('');
                $('#1st_atmp_input').append(html);
            } else {
                var list = $(".1st_input_value").map(function(){return $(this).attr("1st_box_serial");}).get();
                list.reverse();
                console.log(list);
                var j = 0;
                for (var i = boxes; i < list.length; i++) {
                    $("#1st_box_serial_"+list[j]).remove();
                    j++;
                }
            }
        }
    });
</script>

<script>
    $('#2nd_box_item').on('input', function(){
        var prev_box_data = 0;
        ordr = 1;
        var boxes = $('#2nd_box_item').val();
        // console.log(prev_box_data);

        var html = '';
        if(boxes != ''){
            if(parseInt(boxes - prev_box_data) >= 0) {
                var j = parseInt(prev_box_data) + 1;
                console.log(j);
                console.log(boxes);
                // return false;
                for (var i = 1; i <= parseInt(boxes - prev_box_data) ; i++) {
                    html += `
                       <input required id="2nd_box_serial_`+j+`" 2nd_box_serial="`+j+`" style="width: 45px;height: 30px;border: 1px solid #d4d3d3;margin: 4px;float: left;" autocomplete="off" type="number" class="2nd_input_value" name="2nd_input_value[]">
                    `;
                    j++;
                }
                $('#2nd_atmp_input').html('');
                $('#2nd_atmp_input').append(html);
            } else {
                var list = $(".2nd_input_value").map(function(){return $(this).attr("2nd_box_serial");}).get();
                list.reverse();
                console.log(list);
                var j = 0;
                for (var i = boxes; i < list.length; i++) {
                    $("#2nd_box_serial_"+list[j]).remove();
                    j++;
                }
            }
        }
    });
</script>

<script>
    $('#3rd_box_item').on('input', function(){
        var prev_box_data = 0;
        ordr = 1;
        var boxes = $('#3rd_box_item').val();
        // console.log(prev_box_data);

        var html = '';
        if(boxes != ''){
            if(parseInt(boxes - prev_box_data) >= 0) {
                var j = parseInt(prev_box_data) + 1;
                console.log(j);
                console.log(boxes);
                // return false;
                for (var i = 1; i <= parseInt(boxes - prev_box_data) ; i++) {
                    html += `
                       <input required id="3rd_box_serial_`+j+`" 3rd_box_serial="`+j+`" style="width: 45px;height: 30px;border: 1px solid #d4d3d3;margin: 4px;float: left;" autocomplete="off" type="number" class="3rd_input_value" name="3rd_input_value[]">
                    `;
                    j++;
                }
                $('#3rd_atmp_input').html('');
                $('#3rd_atmp_input').append(html);
            } else {
                var list = $(".3rd_input_value").map(function(){return $(this).attr("3rd_box_serial");}).get();
                list.reverse();
                console.log(list);
                var j = 0;
                for (var i = boxes; i < list.length; i++) {
                    $("#3rd_box_serial_"+list[j]).remove();
                    j++;
                }
            }
        }
    });
</script>
