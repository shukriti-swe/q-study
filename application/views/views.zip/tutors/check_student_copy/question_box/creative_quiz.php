<?php
$question_info = json_decode($question_info_s[0]['questionName'], TRUE);
$st_ans = json_decode($tutorial_ans_info[0]['st_ans'], TRUE);
$question_order = $question_info_s[0]['question_order'];

$student_ans = json_decode($st_ans[$question_order]['student_ans'], TRUE);

// echo '<pre>';print_r(json_decode($st_ans[$question_order]['student_ans'], TRUE));die;
?>

<div class="col-sm-4">
    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        <span><img src="assets/images/icon_draw.png"> Instruction</span> Question
                    </a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                    <div class="math_plus">
                        <?php echo $question_info['questionName']; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-4"></div>


