<div class="container">
    <div class="row">

        <div class="sign_up_menu">
            <div class="col-md-6 col-md-offset-3">
                <div class="cancel_clas bottom10">
                    <p><b>Please press the submit button to cancel your subscription</b></p><br>
                    <p>Cancel  subscription will cancel your account.All of your payment to Q-study will be cancelled also.Thanks for using Q-study.</p>
                </div>
                <div class="submit text-center">
                    <br/><br/>
                    <a href="cancel_confirm" class="btn btn_next">Submit</a>
                </div>
            </div>
        </div>
    </div>
</div>