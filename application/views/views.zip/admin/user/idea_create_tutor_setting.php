<div class="" style="margin-left: 15px;">
 	<div class="row">
	   
	   <div class="col-sm-12 ">
	      <div class="ss_question_add_top"> 
	         <div class="form-group" style="float: left;margin-right: 10px;">
	            <label for="exampleInputName2">Grade/Year/Level</label>
	            <div class="select">
	               <select class="form-control" name="studentgrade">
	                  <option value="">Select Grade/Year/Level</option>
	                  <option value="1">
	                     1                
	                  </option>
	                  <option value="2">
	                     2                
	                  </option>
	                  <option value="3" selected="">
	                     3                
	                  </option>
	                  <option value="4">
	                     4                
	                  </option>
	                  <option value="5">
	                     5                
	                  </option>
	                  <option value="6">
	                     6                
	                  </option>
	                  <option value="7">
	                     7                
	                  </option>
	                  <option value="8">
	                     8                
	                  </option>
	                  <option value="9">
	                     9                
	                  </option>
	                  <option value="10">
	                     10                
	                  </option>
	                  <option value="11">
	                     11                
	                  </option>
	                  <option value="12">
	                     12                
	                  </option>
	                  <option value="13">
	                     13                
	                  </option>
	               </select>
	              
	            </div>
	         </div>
	         <div class="form-group" style="float: left;margin-right: 10px;">
	            <label>Subject <span><img src="assets/images/icon_new.png"> New</span> </label>
	            <div class="select">
	               <select class="form-control" name="subject" id="subject" >
	                  <option value="">Select ...</option>
	                  <option value="31" selected="">
	                     Mathematics                
	                  </option>
	                  <option value="43">
	                     Vocabulary                
	                  </option>
	                  <option value="53">
	                     Times Table                
	                  </option>
	                  <option value="71">
	                     Creative Writing                
	                  </option>
	                  <option value="72">
	                     Comprehension                
	                  </option>
	                  <option value="73">
	                     Human Value                
	                  </option>
	                  <option value="89">
	                     Tutorial test                
	                  </option>
	                  <option value="90">
	                     Extra Test                
	                  </option>
	                  <option value="91">
	                     All test subject                
	                  </option>
	                  <option value="92">
	                     work 2                
	                  </option>
	                  <option value="95">
	                     memorize test                
	                  </option>
	                  <option value="100">
	                     Nuriyah                 
	                  </option>
	                  <option value="101">
	                     Mixed                
	                  </option>
	                  <option value="102">
	                     addition                
	                  </option>
	                  <option value="104">
	                     Mixed Subject                
	                  </option>
	                  <option value="126">
	                     assign                
	                  </option>
	                  <option value="127">
	                     new assign                
	                  </option>
	                  <option value="129">
	                     Naplan                
	                  </option>
	               </select>
	             
	            </div>
	         </div>
	         <div class="form-group" style="float: left;margin-right: 10px;">
	            <label>Chapter <span id="get_subject"><img src="assets/images/icon_new.png"> New</span></label>
	            <div class="select">
	               <select class="form-control  " name="chapter" id="subject_chapter">
	                  <option value="">Select Chapter</option>
	                  <option value="33" selected="">
	                     mixed add &amp; sub                
	                  </option>
	                  <option value="59">
	                     Lesson 1                
	                  </option>
	                  <option value="65">
	                     Times table                
	                  </option>
	                  <option value="66">
	                     Times table                
	                  </option>
	                  <option value="67">
	                     another                
	                  </option>
	                  <option value="135">
	                     pytha                
	                  </option>
	                  <option value="141">
	                     alvi                
	                  </option>
	                  <option value="215">
	                     Lesson 1                
	                  </option>
	                  <option value="308">
	                     algo                
	                  </option>
	                  <option value="422">
	                     Shape                
	                  </option>
	                  <option value="438">
	                     Division                
	                  </option>
	                  <option value="439">
	                     test                
	                  </option>
	                  <option value="443">
	                     Test                
	                  </option>
	                  <option value="447">
	                     true                
	                  </option>
	                  <option value="452">
	                     All test chapter                
	                  </option>
	                  <option value="530">
	                     Centre                
	                  </option>
	                  <option value="531">
	                     indices                
	                  </option>
	                  <option value="535">
	                     Yassar                
	                  </option>
	                  <option value="558">
	                     equation                
	                  </option>
	                  <option value="562">
	                     memorise                
	                  </option>
	                  <option value="564">
	                     Centre Final                
	                  </option>
	                  <option value="569">
	                     Indices and surds                 
	                  </option>
	                  <option value="574">
	                     Perimeter                
	                  </option>
	                  <option value="575">
	                     Surd                
	                  </option>
	                  <option value="595">
	                     dividend                
	                  </option>
	                  <option value="660">
	                     new times table                
	                  </option>
	               </select>
	                
	            </div>
	         </div>
	         <div class="form-group" style="float: left;margin-right: 10px;">
	            <label>Country</label>
	            <div class="select">
	               <select class="form-control" name="country" id="quesCountry">
	                  <option value="">Select Country</option>
	                  <option value="1" selected="">AUS</option>
	                  <option value="2">USA</option>
	                  <option value="3">Any</option>
	                  <option value="4">New Zealand</option>
	                  <option value="8">Bangladesh</option>
	                  <option value="9">United Kingdom</option>
	                  <option value="10">Canada</option>
	               </select>  
	            </div>
	         </div>
	         <a class="ss_q_btn btn btn_red pull-left" onclick="open_question_setting()">  Question setting  </a>
	         <button class="ss_q_btn btn pull-left"><i class="fa fa-save" aria-hidden="true" type="submit"></i> Save</button>
	         <a class="ss_q_btn btn pull-left" href="#"><i class="fa fa-remove" aria-hidden="true"></i> Cancel</a>
	         <a class="ss_q_btn btn pull-left hidden" id="preview_btn" href="#" style="">
	         <i class="fa fa-file-o" aria-hidden="true"></i> Preview
	         </a>
	         
	      </div>
	   </div>
	</div> 
    <div class="idea_setting_mid">
    	<div class="form-group" style="float: left;margin-right: 10px;">
            <label><input type="checkbox" name="" <?php if($idea_infos[0]['short_question_allow']==1){echo "checked";}?>> <span><img src="assets/images/icon_new.png"> New</span> </label>
            <div>
            	<button class="btn btn-select active">Shot Question</button>
            </div> 
         </div>
         <div class="form-group" style="float: left;margin-right: 10px;">
            <label><input type="checkbox" name="" <?php if($idea_infos[0]['large_question_allow']==1){echo "checked";}?>> <span><img src="assets/images/icon_new.png"> New</span> </label>
            <div>
            	<button class="btn btn-select  ">Large Question</button>
            </div> 
         </div>
         <div class="form-group" style="float: left;margin-right: 10px;"> 
            <div>
            	<button class="btn btn-select  ">Student Title <input type="checkbox" name="" <?php if($idea_infos[0]['student_title']==1){echo "checked";}?>></button>
            </div> 
         </div>
          <div class="form-group" style="float: left;margin-right: 10px;">
            <label>  <span> Word Limit</span> </label>
            <div>
            	<select class="form-control">
            		<option <?php if($idea_infos[0]['word_limit']==300){echo "selected";}?> value="300">300</option>
            		<option <?php if($idea_infos[0]['word_limit']==250){echo "selected";}?> value="250">250</option>
            		<option <?php if($idea_infos[0]['word_limit']==200){echo "selected";}?> value="200">200</option>
            		<option <?php if($idea_infos[0]['word_limit']==150){echo "selected";}?> value="150">150</option>
            		<option <?php if($idea_infos[0]['word_limit']==100){echo "selected";}?> value="100">100</option>
            		<option <?php if($idea_infos[0]['word_limit']==50){echo "selected";}?> value="50">50</option>
            		<option <?php if($idea_infos[0]['word_limit']==30){echo "selected";}?> value="30">30</option>
            	</select>
            </div> 
         </div>
         <div class="form-group text-center" style="float: left;margin-right: 10px;">
            <label>  <span> Time To Answare</span> </label>
            <div class="d-flex">
            	 <input type="text" class="form-control w-50" name="" value="<?=$idea_infos[0]['time_hour'];?>">
            	 <input type="text" class="form-control w-50" name="" value="<?=$idea_infos[0]['time_min'];?>">
            	 <input type="text" class="form-control w-50" name="" value="<?=$idea_infos[0]['time_sec'];?>">
            </div> 
         </div>
         <div class="form-group text-center" style="float: left;margin-right: 10px;">
            <label>  <span> Allow Ideas</span> </label>
            <div style="height:34px">
            	 <input type="checkbox" name="" <?php if($idea_infos[0]['allow_idea']==1){echo "checked";}?>> 
            </div> 
         </div>
         <div class="form-group text-center" style="float: left;margin-right: 10px;">
            <label>  <span> Add start button</span> </label>
            <div style="height:34px">
            	 <input type="checkbox" name="" <?php if($idea_infos[0]['add_start_button']==1){echo "checked";}?> > 
            </div> 
         </div>

    </div>
    <div class="idea_setting_mid_bottom">
		<?php $k=1; foreach($all_ideas as $idea){ if($k==1){?>
    	<div class="form-group" style="float: left;margin-right: 10px;">
            <label> <span><img src="assets/images/icon_new.png"> New</span> </label>
            <div>
            	<button class="btn btn-select" data-index="<?=$idea_infos[0]['idea_no']?>" style="<?php if($idea_infos[0]['idea_no']==$idea['idea_no']){echo "background: #fb8836f0;";}?>">Idea <?=$idea['idea_no']?></button>
            </div> 
         </div>
		 <?php }else{?>
         <div class="form-group" style="float: left;margin-right: 10px;"> 
            <div>
            	<button style="<?php if($idea_infos[0]['idea_no']==$idea['idea_no']){echo "background: #fb8836f0;";}?>" class="btn btn-select">Idea <?=$idea['idea_no']?></button>
            </div> 
         </div>
		 <?php } $k++; }?>

         
         <div  class="form-group" style="float: left;margin-right: 10px;">
         	<img src="assets/images/icon_s_student.png">
         </div>
         <div  class="form-group" style="float: left;margin-right: 10px;">
         	<img src="assets/images/icon_s_teacher.png">
         </div>
         <div  class="form-group" style="float: left;margin-right: 10px;">
         	<img src="assets/images/icon_a_left.png">
         </div>
         <div  class="form-group" style="float: left;margin-right: 10px;">
         	<img src="assets/images/icon_a_right.png">
         </div>
         <div class="form-group" style="float: left;margin-right: 10px;"> 
            <div>
            	<button class="btn btn-select">Topic/Story Title </button>
            </div> 
         </div>
         <div class="form-group" style="float: left;margin-right: 10px;"> 
            <div>
            	<button class="btn btn-select">Idea Title</button>
            </div> 
         </div>
         <div class="form-group" style="float: left;margin-right: 10px;"> 
            <div>
            	<img src="assets/images/search_a.png" id="advance_searc_op">
            </div> 
         </div>
    </div>
    <div class="row">
    	<div class="col-md-6">
    		 <div class="rs_word_limt">
            	 <div class="top_word_limt">
            	 	<span><?php if($tutor_ans[0]['total_word']){ echo $tutor_ans[0]['total_word'];}?> Words</span>
            	 	<span class="m-auto"><input class="form-control text-center" type="text" value="<?php if($idea_infos[0]['time_hour']){ echo $idea_infos[0]['time_hour'];}?>:<?php if($idea_infos[0]['time_min']){ echo $idea_infos[0]['time_min'];}?>:<?php if($idea_infos[0]['time_sec']){ echo $idea_infos[0]['time_sec'];}?>" name=""></span>
            	 	<span class="m-auto"> Word Limit</span>
            	 	<span class="m-auto b-btn"><?php if($idea_infos[0]['word_limit']){ echo $idea_infos[0]['word_limit'];}?></span>
            	 </div>
				 <input type="hidden" id="module_id" value="<?=$tutor_ans[0]['module_id']?>">
				 <input type="hidden" id="question_id" value="<?=$tutor_ans[0]['question_id']?>">
				 <input type="hidden" id="idea_id" value="<?=$tutor_ans[0]['idea_id']?>">
				 <input type="hidden" id="idea_no" value="<?=$tutor_ans[0]['idea_no']?>">
				 <input type="hidden" id="tutor_id" value="<?=$tutor_ans[0]['tutor_id']?>">
            	 <div class="btm_word_limt">
            	 	<div class="content_box_word">
            	 		<?php echo $tutor_ans[0]['student_ans']?>
            	 	</div>
            	 </div>
            </div>
    	</div>
    	<div class="col-md-6">
    	 <div id="advance_allowonline">
    		<div class="idea_setting_mid flex-end" >
    			<div class="form-group text-center" style="float: left;margin-right: 10px; margin-bottom: 0">
		            <label>  <span> Allow Online</span> </label>
		            <div style="height:34px">
		            	 <input type="checkbox" name="allow_online" value="1"> 
		            </div> 
		         </div>
		         <div class="form-group text-center" style="float: left;margin-right: 10px; margin-bottom: 0;">
		            <label>  <span> Serial No:</span> </label>
		            <div style="height:34px">
		            	 <select class="form-control" name="serial_no" id="serial_no_idea">
		            	 	<option value=""></option>
		            	 	<option value="1">1</option>
		            	 	<option value="2">2</option>
		            	 	<option value="3">3</option>
		            	 	<option value="4">4</option>
		            	 	<option value="5">5</option>
		            	 </select>
		            </div> 
		         </div>
    		</div>
    		<div class="btm_word_limt">
        	 	<div class="content_box_word">
				 <?php echo $tutor_ans[0]['student_ans']?>
        	 	</div>
        	 	<div class="created_name">
        	 		<img src="assets/images/icon_created.png"> <a href="javascript:;" id="open_like_modal"> <u>Topic/Story Created By :</u> </a> &nbsp; <?=$tutor_ans[0]['name']?> 
        	 	</div>
        	 </div>
        	</div>

        	<div id="advance_searc_content">
        		<div class="serach_list"> 
					<div class="input-group">
				      <input type="search" class="form-control" placeholder="Search" name="search" id="advance_searc_content_src">
				      <div class="input-group-btn">
				        <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
				      </div>
				    </div>
        		</div>
        	</div>
    	</div>
    </div>
</div>


<!-- modal -->
<div  class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="login_form">
  <!-- Modal -->
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form class="form-horizontal" method="post">
        <div class="modal-header">
          <h4>&nbsp;</h4>
        </div>
      
        <div class="modal-body">
        
        1 allrady axists

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn_blue" data-dismiss="modal">Ok</button> 
        </div>
      </form>
    </div>
  </div>

</div>

<div  class="modal fade ss_modal " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="topicstory_tutor">
  <!-- Modal -->
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
       
         <div class="mclose" data-dismiss="modal">x</div>
        
        
       <div class="btm_word_limt text-center">

          <input type="hidden" name="tutor_idea_no" id="tutor_idea_no" value="">
          <input type="hidden" name="tutor_id" id="get_tutor_id" value="">
           <p>Tutor(<b class="tutor_name"><?=$tutor_ans[0]['name']?></b>)</p>
           <p><u>Topic/Stoty Title</u></p>
           <p class="blue">"<?=$idea_infos[0]['idea_title']?>"</p>
           <!-- <p > Created: &nbsp; &nbsp; <span id="tutor_submit_date">06/08/2021</span></p> -->
           <div class="clik_point"><i class="fa fa-thumbs-up" aria-hidden="true"></i></div>

           <div class="clik_point_detatis_tutor">
                 <div class="clik_point_detatis">
                  Total Number Of Like <div class="clik_point"><?=$tutor_like[0]['total_like'];?></i></div>
                 </div> 
                 <br>
                 <div class="your_achived_point">
                        Your Achived points <br>
                        <button>15</button>
                 </div>
           </div>
           

       </div>

        
      
    </div>
  </div> 
</div>

<style type="text/css">
.created_name{
	background: #66afe9;
	color: #fff;
	font-size: 16px;
	padding: 10px 20px;
	display: flex;
	flex-wrap: wrap;
	align-items: center;
}
.created_name a{
	color: #fff;
}
.created_name img{
	max-width: 30px;
	margin-right: 10px;
}
.flex-end{
	justify-content: flex-end;
}
	.d-flex{
		display: flex;
	}
	.w-50{
		width: 50px;
	}
	.idea_setting_mid_bottom{
		display: flex;
		align-items: flex-end;
		flex-wrap: wrap;
	}
	.ss_question_add_top { 
		flex-wrap: wrap;
	    display: flex;
	    align-items: flex-start;
	    justify-content: center;
	}
	.ss_question_add_top label, .idea_setting_mid label, .idea_setting_mid_bottom label{
		margin-bottom: 6px;
	}
	.idea_setting_mid {
		display: flex;
		align-items: flex-end;
		flex-wrap: wrap;
	}
    .ss_q_btn { 
    margin-top: 22px;
	}
	.btn-select{
		background: #a9a8a8;
		color: #fff;
		box-shadow: none !important;
		border-radius: 0;
	}
	.btn-select:hover, .btn-select.active{
		background: #00a2e8;
		color: #fff;
	}
	.idea_setting_mid_bottom .btn-select:hover, .idea_setting_mid_bottom .btn-select.active{
		background: #ff7f27;
		color: #fff;
	}
	.top_word_limt{
    	background: #d9edf7;
    	padding: 8px 10px;
    	display: flex;
    	flex-wrap: wrap;
    	align-items: center;
    }
    .m-auto{
    	margin-left: auto;
    }
    .b-btn{
    	background: #9c4d9e;
    	padding: 5px 10px;
    	border-radius: 5px;
    	color: #fff;
    }
	.btm_word_limt .content_box_word{
    	border-radius: 5px;
    	border: 1px solid #82bae6;
    	margin: 10px 0;
    	padding: 10px;
    	width: 100%;
    	box-shadow: 0px 0px 10px #d9edf7;
    }
    .btm_word_limt .content_box_word u{
    	color: #888;
    }
    .btm_word_limt .content_box_word span{
    	color: #888;
    }
    .btm_word_limt .content_box_word p{
    	margin-top: 10px;
    }
    #login_form .modal-content, .ss_modal .modal-content {
	    border: 1px solid #a6c9e2;
	    padding: 5px;
	}
	#login_form .modal-header, .ss_modal .modal-header {
    background: url(assets/images/login_bg.png) repeat-x;
    color: #fff;
    padding: 0;
    border-radius: 5px;
}
#advance_searc_op{
	cursor: pointer;
}
#advance_searc_content{
	display: none;
}
.content_box_word{
	min-height: 300px;
}


.frist_time_user_mid_con_mes strong{
   color: #ff7f27;
}

.frist_time_user_mid_con_mes a{
   color: #00c1f7;
   display: inline-block;
}
.frist_time_user_mid_con a{
   display: inline-block;
}
.frist_time_user_mid_con label{
   margin-bottom: 6px;
}
.frist_time_user_mid_con .image_box{
   border: 1px solid #00c1f7;
   height: 100px;
   width: 100px;
   margin: 10px auto;
   background: #d9d9d9;
}

.clik_point{
   border: 1px solid #4bb04f;
   background: #4bb04f;
   color: #fff;
   height: 60px;
   width: 60px;
   line-height: 55px;
   text-align: center;
   margin: 20px auto;
   border-radius: 50%;
   font-size: 30px;
   cursor: pointer;
}
.clik_point_detatis{
   display: inline-flex;
   justify-content: center;
   align-items: center;
   padding: 20px 0px;
}
.clik_point_detatis .clik_point{
   display: block !important;
   margin-left: 10px;
   border: 1px solid #ff0000;
   background: #ff0000;
   color: #fff;
   height: 60px;
   width: 60px;
   line-height: 55px;
   text-align: center; 
   border-radius: 50%;
   font-size: 30px;
}
.clik_point_detatis_tutor .your_achived_point{
   max-width: 200px;
   margin: auto;
}
#topicstory_tutor .btm_word_limt {
   min-height: 300px;
   padding: 30px;
}
.your_achived_point{
   border: 1px solid #015f4e;
    padding: 15px;
    text-align: center;
    margin: 10px;
    background: #f4f5f9;
}
.your_achived_point button{
   padding: 7px 15px;
   color: #fff;
   background: #015f4e;
   border: 0;
   border-radius: 5px;
   margin-top: 10px;
}
.w-50{
       width: 70px;
    display: inline-block;
}
.profile_right_ida{
   padding: 10px;
padding-top: 20px;
   text-align: center;

}
.profile_right_ida .welcom_mes {
   font-size: 13px;
   line-height: 16px;
   margin: 20px 0px;
   padding: 10px;
   background: #b5e61d;
   border: 1px solid #0079bc;
}
.profile_right_ida u{
   color: #7f7f7f;
}
.profile_right_ida .btn-primary{
   margin-bottom: 5px;
   background: #fff;
   color: #333;
   padding: 6px 15px;
   border-radius: 0;
   line-height: 16px;
   border: 1px solid #c3c3c3;
}
.profile_right_ida .btn-primary:hover{
   background: #a349a4;
   color: #fff;
   padding: 6px 15px;
   border-radius: 0;
   line-height: 16px;
}

#show_question_idea_profile table{
   font-size: 13px;
}
.profile_right_ida_bottom {
   padding:0 10px;
}
.profile_right_ida_bottom .table>thead>tr>th {
    border-bottom: 2px solid #e6eed5;
}
  .red {
    color: #ff0000;
}
 .blue {
    color: #00b0f0;
}
  .gold {
    color: #e36c09;
}
  .green {
    color: #00b050;
}
  .orange {
    color: #953734;
}
.profile_right_ida_bottom .table tbody tr > td {
    text-align: center;
    padding: 4px 10px;
    color: #ed1c24;
}
.profile_right_ida_bottom .table tbody tr {
    background: #e6eed5;
    border-bottom: 20px solid #fff;
}
.profile_right_ida_bottom .table input{
   margin: 0;
}

.profile_right_ida_bottom .table tbody tr > td:first-child {
    text-align: left;
    color: #76923c;
    font-weight: bold;
}
.profile_right_ida_bottom .table input[type=checkbox]:focus
      {
          outline: none;
      }

  .profile_right_ida_bottom .table input[type=checkbox]
   {
       background-color: #fff;
       border-radius: 2px;
       appearance: none;
       -webkit-appearance: none;
       -moz-appearance: none;
       width: 14px;
       height: 14px;
       cursor: pointer;
       position: relative; 
       border: 1px solid #959595;
   }

   .profile_right_ida_bottom .table input[type=checkbox]:checked
   {
      border: 1px solid #0699ef;
       background-color: #0699ef;
       background: #0699ef url("data:image/gif;base64,R0lGODlhCwAKAIABAP////3cnSH5BAEKAAEALAAAAAALAAoAAAIUjH+AC73WHIsw0UCjglraO20PNhYAOw==") 3px 3px no-repeat;
       background-size: 8px;
   } 
@media (min-width: 1000px){
#show_question_idea_profile .modal-dialog{
   width: 800px;
}
}
  #show_question_idea_profile{
      overflow-y: scroll;
   }
.profile_left_ida table{
   margin-top: 10px;
}
.profile_left_ida table tr td{
   border: none;
   padding: 0;
   color: #7f7f7f;
   font-size: 13px;
}
.p-3{
   padding: 15px;
}
.ss_modal .modal-content {
    border: 1px solid #a6c9e2;
    padding: 0;
    margin: 0;
}
.top_textprev{
   padding-bottom: 20px;
}
.top_textprev h4{
   color: #7f7f7f;
   font-size: 16px;
   font-weight: bold;
}
.top_textprev .btn{
   background: #9c4d9e;
   border-radius: 0;
   border: none;
   color: #fff;
   padding: 8px 20px;
   margin-top: 10px;
   margin-bottom: 20px;
}
.top_textprev h6{
   color: #000;
   font-size: 14px;
   font-weight: bold;
}
.workout_menu{
   height: initial;
}
.workout_menu ul{
   margin-bottom: 20px;
   display: flex;
   align-items: end;
   flex-wrap: wrap;
}
.workout_menu ul > div{ 
   margin-bottom: 10px;
}
    .top_word_limt{
    	background: #d9edf7;
    	padding: 8px 10px;
    	display: flex;
    	flex-wrap: wrap;
    	align-items: center;
    }
    .m-auto{
    	margin-left: auto;
    }
    .b-btn{
    	background: #0079bc;
    	padding: 5px 10px;
    	border-radius: 5px;
    	color: #fff;
    }
    #login_form .modal-dialog, .ss_modal .modal-dialog {
       max-width: 100%;
   }
    .btm_word_limt .content_box_word{
    	border-radius: 5px;
    	border: 1px solid #82bae6;
    	margin: 10px 0;
    	padding: 10px;
    	width: 100%;
    	box-shadow: 0px 0px 10px #d9edf7;
      margin-top: 0 !important;
    }
    .btm_word_limt .content_box_word u{
    	color: #888;
    }
    .btm_word_limt .content_box_word span{
    	color: #888;
    }
    .btm_word_limt .content_box_word p{
    	margin-top: 10px;
    }
    .ss_modal .modal-dialog{
      position: absolute;
      margin-top: 0% !important; 
    top: 50% !important;   
    left: 50% !important;    
    transform: translate(-50%, -50%) !important;  
    }

    .ss_modal .modal-content { 
       padding: 5px !important; 
   }

 .ss_modal .modal-header {
    background: url(assets/images/login_bg.png) repeat-x;
    color: #fff;
    padding: 0;
    border-radius: 5px;
}
 
#show_question_idea_profile .modal-dialog {
    position: relative;
    margin-top: 2% !important;
    top: 0 !important;
    left: auto !important;
    transform: translate( 0%, 0%) !important;
}
.created_name {
    background: #66afe9;
    color: #fff;
    font-size: 16px;
    padding: 10px 20px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
}
.mclose{
   position: absolute;
   right: 10px;
   top: 10px;
   font-size: 20px;
   z-index: 10;
   cursor: pointer;
}
.created_name img {
    max-width: 30px;
    margin-right: 10px;
}
.created_name a {
    color: #fff;
}
</style>
<script type="text/javascript"> 

	$("#serial_no_idea").on("change", function () {        
	    $modal = $('#login_form');
	    if($(this).val() === '1'){
	        $modal.modal('show');
	    }
	});
	$(document).ready(function(){
	  $("#advance_searc_op").click(function(){
	    $("#advance_allowonline").toggle();
	    $("#advance_searc_content").toggle();
	  });
	 
	});

	$(".clik_point").on("click", function () {
      
	  var question_id= $("#question_id").val();
	  var module_id= $("#module_id").val();
	  var idea_id =$("#idea_id").val();
	  var idea_no =$("#idea_no").val();
	  var tutor_id = $("#tutor_id").val();
	//   alert(question_id);  
	//   alert(module_id);  
	//   alert(idea_id);  
	//   alert(idea_no);  alert(tutor_id);  
		 $.ajax({
			url: "Student/add_tutor_like",
				   method: "POST",
				   data: {question_id:question_id,module_id:module_id,idea_id:idea_id,idea_no:idea_no,tutor_id:tutor_id},
				   dataType: 'json',
				   success: function(data) {
				  console.log(data);
				  
				  
				  if(data.insert_or_update == 1){
					  alert('like added');
				   }else{
					  alert('allready like added');
				   }
				  $(".clik_point").text(data.total_like);
				  $('.clik_point_detatis_tutor').show();       
				  $('.clik_point').hide();
			   }
   
		 })
	  
	  });
$( function() {
    var availableTags = [
      "ActionScript",
      "AppleScript",
      "Asp",
      "BASIC",
      "C",
      "C++",
      "Clojure",
      "COBOL",
      "ColdFusion",
      "Erlang",
      "Fortran",
      "Groovy",
      "Haskell",
      "Java",
      "JavaScript",
      "Lisp",
      "Perl",
      "PHP",
      "Python",
      "Ruby",
      "Scala",
      "Scheme"
    ];
    $( "#advance_searc_content_src" ).autocomplete({

      source: availableTags
    });
  } );
//   data-toggle="modal" data-target="#topicstory_tutor" ;
  $("#open_like_modal").click(function(){
     
	$("#topicstory_tutor").modal("show");
  });
</script>