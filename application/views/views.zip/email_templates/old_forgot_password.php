<style>
*{ margin:0px; padding:0px;}
</style>
<div style="padding:0px; margin:0px; font-size:14px; color:#222; line-height:24px; max-width:500px;">
	<div ><img src="http://wa.rssoft.win/Q-Study/assets/images/icon_logo_small.png" alt="logo"/> Hello,<?php echo $user; ?></div>
	<p>Forgot password?</p>
	<p>click on the link below to reset your password</p>
	<a href="<?php echo $resetLink; ?>">password reset link</a>
	<div style="width:100%; ">

	</div>
	<br/>
	<p>Thank you using for Q-Study</p>
	<br/>
	<p><img src="http://wa.rssoft.win/Q-Study/assets/images/logo_signup.png" alt="logo"/></p>
	
</div>