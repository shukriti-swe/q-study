<style>
    strong{
        color:#007AC9;
    }
</style>

<strong>Question Info</strong>
<br><br>
<div class="row">
    <div class="col-md-1">
        <p style="color:red !important">Question:</p>
    </div>
    <div class="col-md-10">
        <?php echo  $quesInfo['questionName']; ?>
    </div>
</div>

<br><br>
<strong>Answer</strong>
<p><?php echo $quesInfo['answer']; ?></p>
<br>
