<style>
    strong{
        color:#007AC9;
    }
</style>

<strong>Question Info</strong>
<br>
<p><span style="color:red !important">Definition      : </span><?php echo  $additionalInfo['definition']; ?></p>
<p><span style="color:red !important">Parts Of Speech : </span><?php echo  $additionalInfo['parts_of_speech']; ?></p>
<p><span style="color:red !important">Synonym         : </span><?php echo  $additionalInfo['synonym']; ?></p>
<p><span style="color:red !important">Antonym         : </span><?php echo  $additionalInfo['antonym']; ?></p>
<p><span style="color:red !important">Sentence        : </span><?php echo  $additionalInfo['sentence']; ?></p>
<p><span style="color:red !important">Category        : </span><?php echo  $additionalInfo['near_antonym']; ?></p>

<br>
<strong>Answer</strong>
<p><?php echo $quesInfo['answer']; ?></p>
<br>