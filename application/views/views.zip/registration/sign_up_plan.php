<?php echo $header; ?>
<?php echo $header_sign_up; ?> 
			<div class="container">
				 <div class="row">
				 	<div class="col-sm-8 col-sm-offset-2">
						<div class="sign_up_menu_plan">
							 
							<ul>
								<li>
									<a href="<?php echo base_url(); ?>select_country">Choose Country <img src="<?php echo base_url(); ?>assets/images/icon_cuntry.png"></a>
								</li>
								<li>
									<a>Choose Plan <img src="<?php echo base_url(); ?>assets/images/icon_plan.png"></a>
								</li>
								<li>
									<a>Create Account <img src="<?php echo base_url(); ?>assets/images/icon_account.png"></a>
								</li>
							</ul>
							<!--<div class="text-right"> 
								<a class="btn btn_next" href="<?php echo base_url(); ?>select_country"><img src="<?php echo base_url(); ?>assets/images/arrow_next.png"/>Next</a>
							</div>-->
						</div>
				 	</div>
				 </div>
			</div>
		</div>
</section>
<?php echo $footer; ?>
 