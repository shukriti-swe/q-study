 <?php include("header.php"); ?>
<section class="main_content ss_sign_up_content bg-gray animatedParent">
		<div class="container-fluid container-fluid_padding">
			<div class="row"> 
				 <div class="sign_up_header">
				 	<div class="col-sm-4"></div>
				 	<div class="col-sm-4 text-center">
				 		<a href="#"><img src="assets/images/logo_signup.png"></a>
				 	</div>
				 	<div class="col-sm-4">
				 		<div class="top_signup">
				 			<ul>
				 				<li><a href="#">Back</a></li>
				 				<li><a href="#"><img src="assets/images/icon_video.png"/> Video Help </a><span>1</span></li>
				 			</ul>
				 		</div>
				 	</div>
				 </div>
			</div> 
			
		</div>
		
		<div class="container">
				<div class="row top100">
					
				
					<div class="col-md-8 col-md-offset-2">
					<div class="blue_photo bottom10">
					<a href="">Logo / Photo</a></div>
						<div class="wrapper">
						  <div class="drop">
							<div class="cont">
							  <i class="fa fa-cloud-upload"></i>
							  <div class="tit">
								Drag & Drop
							  </div>
							  <div class="desc">
								your files to Assets, or 
							  </div>
							  <div class="browse">
								Chose photo to upload
							  </div>
							</div>
							<output id="list"></output><input id="files" multiple="true" name="files[]" type="file" />
						  </div>
						</div>
					</div>
			
			 </div>
			 </div>
</section>
<?php include("footer.php"); ?>
 