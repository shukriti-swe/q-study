 
<div class="container">
    <div class="row">

        <div class="sign_up_menu">
            <div class="col-md-6 col-md-offset-3">
                <div class="cancel_clas bottom10 text-center">
                    <p><b>Your subscription has been successfully canceled</b></p><br>
                </div>
            </div>
        </div>
    </div>
</div>

